package com.example.d2m.ui.fragments

import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.d2m.*
import com.example.d2m.adapter.ProfileAdapter
import com.example.d2m.model.HomeResponse1
import com.example.d2m.model.SessionManager
import kotlinx.android.synthetic.main.fragment_home.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.reflect.jvm.internal.impl.storage.NullableLazyValue

const val BASE_URL_HOME = "api/v1/service-provider/service-provider-home"
class HomeFragment : Fragment() {

    //token
    private lateinit var sessionManager: SessionManager
    private lateinit var apiClient: ApiClient
    lateinit var myAdapter: ProfileAdapter
    var dataList = ArrayList<HomeResponse1>()

    private lateinit var newRecyclerView: RecyclerView
    private var newArrayList: ArrayList<HomeResponse1.Data.Technician>? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {

         //var token = intent.getStringExtra("token")
         //var userID = intent.getStringExtra("userID")
        // sessionManager = SessionManager(this)
        apiClient = ApiClient()

        val userID = null
        val token = null
        getUserdata(userID, token)

        return inflater.inflate(R.layout.fragment_home, container, false)

    }
    private fun getUserdata(userID: String?, token: String?) {
        val apiInterface = ApiInterface.create().serviceProviderHome(userID ?: "17", "2022-01-11")

        apiInterface.enqueue(object : Callback<HomeResponse1> {
            override fun onResponse(
                call: Call<HomeResponse1>,
                response: Response<HomeResponse1>,
            ) {
                Log.d("Success:", response.body().toString())
                if (response.body()?.success == true) {
                    response.body()?.let {
                        dataList.addAll(arrayListOf(it))
                    }
                    response.body()?.data?.technician?.let { newArrayList?.addAll(it) }
                    response.body()?.data?.technician?.apply {
                        myAdapter = ProfileAdapter(this)
                        newRecyclerView.adapter = myAdapter
                        newRecyclerView.adapter!!.notifyDataSetChanged()
                    }
                } else {
                    Toast.makeText(context,
                        response.body()?.message,
                        Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(call: Call<HomeResponse1>, t: Throwable) {
                Toast.makeText(context, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }
}

