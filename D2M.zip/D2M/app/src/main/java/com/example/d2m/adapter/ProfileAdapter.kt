
package com.example.d2m.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.d2m.R
import com.example.d2m.model.HomeResponse1
import com.google.android.material.imageview.ShapeableImageView

class ProfileAdapter(private var homeResponse1: ArrayList<HomeResponse1.Data.Technician>) : RecyclerView.Adapter<ProfileAdapter.MyViewHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent?.context).inflate(R.layout.sp_horizontal_list, parent, false)
        return MyViewHolder(itemView)
    }
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var titleImage: ShapeableImageView = itemView.findViewById(R.id.title_image)
        var textViewHeading : TextView = itemView.findViewById(R.id.text_view_heading)
        var textViewName: TextView = itemView.findViewById(R.id.text_view_name)
        var textViewAddress: TextView = itemView.findViewById(R.id.text_view_address)
    }
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.textViewName.text = homeResponse1[position].toString()
        holder.textViewHeading.text = homeResponse1[position].toString()
        holder.textViewAddress.text = homeResponse1[position].toString()
    }
    override fun getItemCount(): Int {
        return homeResponse1.size
    }
}
/*class MyAdapter(private var dataList: MutableList<HomeResponse1>): RecyclerView.Adapter<WorkerAdapter.MyViewHolder>(){
    private lateinit var context: Context
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WorkerAdapter.MyViewHolder {
        context = parent.context
        return WorkerAdapter.MyViewHolder(LayoutInflater.from(context).inflate(R.layout.sp_horizontal_list, parent,false))
    }

    override fun onBindViewHolder(holder: WorkerAdapter.MyViewHolder, position: Int) {

    }

    override fun getItemCount(): Int {

    }

}*/
