package com.example.d2m.model


import com.google.gson.annotations.SerializedName

data class LoginApiResponse(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("message")
    val message: String,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("address")
        val address: String,
        @SerializedName("city")
        val city: Int,
        @SerializedName("email")
        val email: String,
        @SerializedName("full_name")
        val fullName: String,
        @SerializedName("id")
        val id: Int,
        @SerializedName("is_mobile_verified")
        val isMobileVerified: Int,
        @SerializedName("is_profile_done")
        val isProfileDone: Int,
        @SerializedName("phone")
        val phone: String,
        @SerializedName("profile_pic")
        val profilePic: String,
        @SerializedName("service_provider_area")
        val serviceProviderArea: String,
        @SerializedName("services")
        val services: List<Service>,
        @SerializedName("token")
        val token: String,
        @SerializedName("user_type")
        val userType: String,
        @SerializedName("working_days")
        val workingDays: String,
        @SerializedName("working_time")
        val workingTime: String
    ) {
        data class Service(
            @SerializedName("brands_ids")
            val brandsIds: List<Int>,
            @SerializedName("service_cat_id")
            val serviceCatId: Int
        )
    }
}