package com.example.d2m.model


import com.google.gson.annotations.SerializedName

data class TokenResponse(
    @SerializedName("message")
    val message: String,
    @SerializedName("success")
    val success: Boolean
)