package com.example.d2m.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.d2m.R
import com.google.android.material.imageview.ShapeableImageView

class WorkerAdapter (private var worker : ArrayList<WorkerAdapter>) : RecyclerView.Adapter<WorkerAdapter.MyViewHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.worker_detail_list, parent, false)
        return MyViewHolder(itemView)
    }
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.textViewName.text = worker[position].toString()
        holder.textViewTechnician.text = worker[position].toString()

    }
    override fun getItemCount(): Int {
        return worker.size
    }
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var titleImage: ShapeableImageView = itemView.findViewById(R.id.img_profile_pick)
        var textViewName : TextView = itemView.findViewById(R.id.tv_worker_name)
        var textViewTechnician: TextView = itemView.findViewById(R.id.tv_title_technician)
    }
}