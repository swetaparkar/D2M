package com.example.d2m

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class
TechnicianLoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_technician_login)
        supportActionBar?.hide()

        val editTextMobile = findViewById<EditText>(R.id.editText_email)
        val button = findViewById<Button>(R.id.button_technician_login)

        button.setOnClickListener {
            if (TextUtils.isEmpty(editTextMobile.text.toString())) {
                Toast.makeText(this@TechnicianLoginActivity,
                    " Please Enter Mobile",
                    Toast.LENGTH_SHORT).show()
            }
         //   val intent = Intent(applicationContext, TechnicianDashboardMainActivity::class.java)
           // startActivity(intent)
        }
    }
}




