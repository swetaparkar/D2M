package com.example.d2m

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        supportActionBar?.hide()

        val buttonSp = findViewById<Button>(R.id.btn_sp_login)
        val buttonTechnician = findViewById<Button>(R.id.btn_login_technician)

        buttonSp.setOnClickListener {
            intent = Intent(applicationContext, ServiceProviderLoginActivity::class.java)
            startActivity(intent)
        }
        buttonTechnician.setOnClickListener {
            intent = Intent(applicationContext,TechnicianLoginActivity::class.java)
            startActivity(intent)
        }

    }
}