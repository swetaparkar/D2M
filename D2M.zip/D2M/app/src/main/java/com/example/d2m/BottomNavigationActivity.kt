package com.example.d2m

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.d2m.ui.gallery.GalleryFragment
import com.example.d2m.ui.fragments.HomeFragment
import com.example.d2m.ui.fragments.OrderFragment
import com.example.d2m.ui.slideshow.SlideshowFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class BottomNavigationActivity : AppCompatActivity() {
    private var currentMenuItem: MenuItem? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bottom_navigation)


        val homeFragment = HomeFragment()
        val orderFragment = OrderFragment()
        val technicianFragment = TechnicianFragment()
        val profileFragment = TechnicianProfileFragment()
        setCurrentFragment(homeFragment)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNav.setOnNavigationItemSelectedListener {
           //for menu2
            when(it.itemId){
                R.id.homeFragment ->setCurrentFragment(homeFragment)
                R.id.orderFragment ->setCurrentFragment(orderFragment)
                R.id.technicianFragment ->setCurrentFragment(technicianFragment)
                R.id.profileFragment -> setCurrentFragment(profileFragment)
            }
            true
        }
    }


    private fun setCurrentFragment(fragment:Fragment)=
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.flFragment,fragment)
            commit()
        }

    internal class BottomNaviAdapter(fragmentManager: FragmentManager, lifecycle: Lifecycle) : FragmentStateAdapter(fragmentManager, lifecycle){
        override fun getItemCount(): Int {
            return 3
        }

        override fun createFragment(position: Int): Fragment {
            return when(position){
                0 -> HomeFragment()
                1 -> GalleryFragment()
                2 -> SlideshowFragment()
                else -> HomeFragment()

            }
        }
    }
}