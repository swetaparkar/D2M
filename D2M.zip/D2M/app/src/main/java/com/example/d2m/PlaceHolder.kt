package com.example.d2m

import java.util.*

class PlaceHolder {
}
data class LoginResponseData (
    val success: Boolean,
    val email: String,
    val password: String
)
data class VerifyResponse (
    val success: Boolean,
    val data: LoginResponseData,
    val message: String
)
data class VerifyLoginResponse (
    val success: Boolean,
    val message: String,
    val user_id: Int,
    val date: Date
)
data class VerifyHome (
    val success: Boolean,
    val user_id: Int,
    val date: Date
)

// sp dashBoard Activity
data class OnGoingService(var titleImage: Int, var heading: String, var name:String, var address:String)

data class OrderList(var title: String, var numberOfOrder: String)

data class Worker(var titleImage: Int, var name:String, var technician:String)
