package com.example.d2m


import com.google.gson.annotations.SerializedName

data class PostmanPlaceHolder(
    @SerializedName("info")
    val info: Info,
    @SerializedName("item")
    val item: List<Item>
) {
    data class Info(
        @SerializedName("name")
        val name: String,
        @SerializedName("_postman_id")
        val postmanId: String,
        @SerializedName("schema")
        val schema: String
    )

    data class Item(
        @SerializedName("name")
        val name: String,
        @SerializedName("protocolProfileBehavior")
        val protocolProfileBehavior: ProtocolProfileBehavior,
        @SerializedName("request")
        val request: Request,
        @SerializedName("response")
        val response: List<Any>
    ) {
        data class ProtocolProfileBehavior(
            @SerializedName("disableBodyPruning")
            val disableBodyPruning: Boolean
        )

        data class Request(
            @SerializedName("auth")
            val auth: Auth,
            @SerializedName("body")
            val body: Body,
            @SerializedName("header")
            val header: List<Any>,
            @SerializedName("method")
            val method: String,
            @SerializedName("url")
            val url: String
        ) {
            data class Auth(
                @SerializedName("bearer")
                val bearer: Bearer,
                @SerializedName("type")
                val type: String
            ) {
                data class Bearer(
                    @SerializedName("token")
                    val token: String
                )
            }

            data class Body(
                @SerializedName("formdata")
                val formdata: List<Formdata>,
                @SerializedName("mode")
                val mode: String,
                @SerializedName("options")
                val options: Options,
                @SerializedName("raw")
                val raw: String,
                @SerializedName("urlencoded")
                val urlencoded: List<Urlencoded>
            ) {
                data class Formdata(
                    @SerializedName("description")
                    val description: String,
                    @SerializedName("disabled")
                    val disabled: Boolean,
                    @SerializedName("key")
                    val key: String,
                    @SerializedName("src")
                    val src: Any,
                    @SerializedName("type")
                    val type: String,
                    @SerializedName("value")
                    val value: String
                )

                data class Options(
                    @SerializedName("raw")
                    val raw: Raw
                ) {
                    data class Raw(
                        @SerializedName("language")
                        val language: String
                    )
                }

                data class Urlencoded(
                    @SerializedName("description")
                    val description: String,
                    @SerializedName("disabled")
                    val disabled: Boolean,
                    @SerializedName("key")
                    val key: String,
                    @SerializedName("type")
                    val type: String,
                    @SerializedName("value")
                    val value: String
                )
            }
        }
    }
}