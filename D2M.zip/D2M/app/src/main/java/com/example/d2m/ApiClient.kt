package com.example.d2m

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class ApiClient {
    private lateinit var apiInterface: ApiInterface
    fun getApiService(): ApiInterface {
        // Initialize ApiService if not initialized yet
        if (!::apiInterface.isInitialized) {
            val retrofit = Retrofit.Builder()
               // .baseUrl(ApiInterface.Companion.Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            apiInterface = retrofit.create(ApiInterface::class.java)
        }
        return apiInterface
    }

}