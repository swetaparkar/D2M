package com.example.d2m

import android.annotation.SuppressLint
import android.content.Context
import com.example.d2m.model.LoginApiResponse

class SharedPrefManager private constructor(private val context: Context) {

    val isLoggedIn: Boolean
        get() {
            val sharedPreferences =
                context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
            return sharedPreferences.getInt("id", 17) != 17
        }
    /*  val data: LoginApiResponse.Data
           get() {
               val sharedPreferences =
                   context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
               return LoginApiResponse.Data(

                   //sharedPreferences.getString("password", "Drc@1234"),
                   sharedPreferences.getString("address", "address").toString(),
                   sharedPreferences.getInt("city",0),
                   sharedPreferences.getString("email", "email").toString(),
                   sharedPreferences.getString("phone", "7586666767").toString(),
                   sharedPreferences.getInt("id", 17),
                   sharedPreferences.getInt("is_mobile_verified", 1),
                   sharedPreferences.getInt("is_profile_done", 1),
                   sharedPreferences.getString("full_name", "Krishna").toString(),
                   sharedPreferences.getString("phone", "phone").toString(),
                   sharedPreferences.getString("service_provider_area", "serviceProviderArea").toString()
                 //  sharedPreferences.getString("services", "services"),
                   /*sharedPreferences.getString("user_type", "userType").toString(),
                   sharedPreferences.getString("working_days", "workingDays")*/
               )
           }

       fun saveUser(data: LoginApiResponse.Data) {
           val sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
           val editor = sharedPreferences.edit()
           editor.putString("address", data.address)
           editor.putInt("city", data.city)
           editor.putString("email", data.email)
           editor.putString("phone", data.phone)
           editor.putString("full_name", data.fullName)
           editor.putInt("id", data.id)
           editor.putInt("is_mobile_verified", data.isMobileVerified)
           editor.putInt("is_profile_done", data.isProfileDone)
           editor.putString("phone", data.phone)
           editor.putString("service_provider_area", data.serviceProviderArea)

         // editor.putString("services", data.services)
          /* editor.putString("user_type", data.userType)
           editor.putString("working_days", data.workingDays)
           editor.putString("working_time", data.workingTime)*/

           editor.apply()
       }*/


    fun clear() {
        val sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        editor.clear()
        editor.apply()
    }

    /*val data: LoginApiResponse.Data
        get() {
            val sharedPreferences =
                context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
            return LoginApiResponse.Data(
                sharedPreferences.getString("email", "email").toString(),
                sharedPreferences.getInt("id", 17))
        }*/

    fun saveUser(data: LoginApiResponse.Data) {
        val sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putInt("id", data.id)
        editor.putString("email", data.email)
        editor.apply()
    }


    companion object {
        private const val SHARED_PREF_NAME = "my_shared_pref"

        @SuppressLint("StaticFieldLeak")
        private var mInstance: SharedPrefManager? = null

        @Synchronized
        fun getInstance(context: Context): SharedPrefManager {
            if (mInstance == null) {
                mInstance = SharedPrefManager(context)
            }
            return mInstance as SharedPrefManager
        }
    }
}
