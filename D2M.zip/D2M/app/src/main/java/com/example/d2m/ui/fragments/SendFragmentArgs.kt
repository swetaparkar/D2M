package com.example.d2m.ui.fragments

import androidx.navigation.NavArgs

class SendFragmentArgs : NavArgs {

    val nam: String
        get() {
            TODO()
        }
}
