package com.example.d2m.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.navArgs
import com.example.d2m.R


class SendFragment : Fragment() {
    private val args: SendFragmentArgs by navArgs<SendFragmentArgs>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        return inflater.inflate(R.layout.fragment_send, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val button: Button = view.findViewById(R.id.btn_send_message)
        val etText: EditText = view.findViewById(R.id.et_msg_title)
        val  tv: TextView = view.findViewById(R.id.tv_Show)

        val name: String = args.nam
        tv.text = name

        button.setOnClickListener {

            Toast.makeText(requireContext(), "Send Fragment", Toast.LENGTH_SHORT).show()

        }
    }
}

