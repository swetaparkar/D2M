package com.example.d2m

import com.example.d2m.model.HomeResponse1
import com.example.d2m.model.LoginApiResponse
import com.example.d2m.model.TokenResponse
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.*
import java.util.*

//for sp dashboard
private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
private val retrofit = Retrofit.Builder().addConverterFactory(MoshiConverterFactory.create(moshi)).baseUrl(BASE_URL).build()

interface ApiInterface {
    //token
    @POST(Constants.HOME_URL)
    //pass data in header
    @Headers("post")
    //login
    @GET("posts")
    fun getData(): Call<List<LoginResponseData>>

    //dashboard Home
    @GET("posts")
    fun getDataHome(): Call<List<VerifyLoginResponse>>

    //dashboard
    @GET(".")
    fun getAllData(): Call<List<HomeResponse1.Data>>


    @FormUrlEncoded
    @POST("/api/v1/service-provider/login")
    fun loginReq(
        @Field("email") email: String,
        @Field("password") password: String,
    ): Call<LoginResponseData>

    fun homResponse(
        @Field("email") email: String,
        @Field("password") password: String,
    ): Call<VerifyLoginResponse>

    @FormUrlEncoded
    @POST("/api/v1/service-provider/login")
    fun serviceProviderLogin(
        @Field("email") email: String,
        @Field("password") passwordRetrofitInstanced: String,
        @Field("device_token") androidToken: String,
        @Field("device_type") deviceType: String,
        @Field("with_mobile") with_mobile: Int,
        @Field("phone") phone: Long,
        @Field("whatsapp_updates") whatsappUpdates: String,
    ): Call<LoginApiResponse>

    @FormUrlEncoded
    @POST("api/v1/service-provider/service-provider-home")
    fun serviceProviderHome(
        @Field("user_id") user_id: String,
        @Field("date") date: String,
    ): Call<HomeResponse1>

    fun worker(
        @Field("id") id: Int,
        @Field("full_name") user_id: String,
        @Field("service_provider_id") service_provider_id: String,
        @Field("email") email: String,
        @Field("phone") phone: Int,
        @Field("aadhar_card_no") aadhar_card_no: Int,
        @Field("profile_pic") profile_pic: String,
    ): Call<HomeResponse1>

    fun onGoingService(
        @Field("id") id: Int,
        @Field("full_name") user_id: String,
        @Field("service_provider_id") service_provider_id: String,
        @Field("email") email: String,
        @Field("phone") phone: Int,
        @Field("aadhar_card_no") aadhar_card_no: Int,
        @Field("profile_pic") profile_pic: String,
    ): Call<HomeResponse1>

    //home response
    fun fetchPosts(@Header("Authorization") token: String): Call<TokenResponse>

    // pass data in header
    companion object {
        private var BASE_URL = "http://d2m.php.dev.drcsystems.ooo"

        fun create(): ApiInterface {
            val retrofit = Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(BASE_URL)
                .client(client)
                .build()
            return retrofit.create(ApiInterface::class.java)
        }
        val client: OkHttpClient = OkHttpClient.Builder().apply {
            val interceptor = OkHttpClient.Builder()
            interceptor.addInterceptor { chain ->
                val original = chain.request()
                val requestBuilder = original.newBuilder()
                    .header("Authorization",
                        "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiMTliNGQ3NGI2ODE2NWUwZmY0NjA1MTY2N2FkMDg0YTAwODY2ZWE1NmY0NjI5MGEzOWM5NDMzMjFiZjYyZWZkOGJkNmI5ZGM4MjE2ZjgzZmUiLCJpYXQiOjE2NDU1OTUwMTksIm5iZiI6MTY0NTU5NTAxOSwiZXhwIjoxNjc3MTMxMDE5LCJzdWIiOiIxNyIsInNjb3BlcyI6W119.nkAyu0UFF_vkqcfRRXIRp_Gj1xO6BATHcy-SxI9z0Tqfl-ujJkGuhOc_XXUj1IkIcIu5ZtS0f6v3wayUKGNuRG9FiJzn6MPVVlgwTsYKz6cA0n5YKTss3-15KK_1Upu73AKmgvqYwHmoSQaE8MOdUD-UDlwRMLeFtQUzWsFUq_b0OUnI-FsJdQGkkf7jkQeY9WdJpHRSPNA_FE5yGys-iAwZEA7t3dmyb4VvXV-Qjri5HbraM9Xx4EchkzqPZcx_yEYNNOGxpOtu1Uq7zzFLB0sCQZEYfBQZE2kxW0D9r4kxmlWX6UA2lEyLEiBo8LquvvrFpSN02HV4ha4-ye2HJa9DVqLZ89usgv2unzYYGq3ZI0dLH8ZTsUHHITWqfrUsZZHv7lZeRgc2V7bp_G2F7gXX0IATMLTOtNS0GbFAwRgaiuyzqWmhOB7ct6dAUlGJVD2WpdrRusgsW_EONLRRg0MGpN8iwCYaeJEOwwnyfrMUO4xYuAfYwik5I4HHNGGPkdpj-7EyOCV7OvJhS7mIRW-oE_cGtHKoOyzySTnOZUEfBaz1F654YETJHzZxVmjTvf-tkSDUz4R_PlvpOc3QpB9giTOWEq5HSSJTKLgkJmQUehkKCpEdiksbckgYd6asA9IVEtJZI1gzzjgsyQHjjawReGa1a3F8FozahpazKH4")
                val request = requestBuilder.build()
                chain.proceed(request)
            }
            //this.addInterceptor(interceptor)
        }.build()
    }
    object Constants {
        // Endpoints
        const val BASE_URL = "http://d2m.php.dev.drcsystems.ooo"
        const val HOME_URL = "api/v1/service-provider/service-provider-home"
        const val POSTS_URL = "posts"
    }
    object  Api {
        val retrofitService: ApiInterface by lazy {
            retrofit.create(ApiInterface::class.java)
        }
    }
}


