package com.example.d2m.model


import com.google.gson.annotations.SerializedName

data class HomeResponse1(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("message")
    val message: String,
    @SerializedName("success")
    val success: Boolean
){
    data class Data(
        @SerializedName("ongoing_orders")
        val ongoingOrders: List<Any>,
        @SerializedName("technician")
        val technician: ArrayList<Technician>? = null,
        @SerializedName("today_order")
        val todayOrder: Int,
        @SerializedName("total_completed_order")
        val totalCompletedOrder: Int
    ) {
        data class Technician(
            @SerializedName("aadhar_card_no")
            val aadharCardNo: String,
            @SerializedName("assign")
            val assign: Int,
            @SerializedName("email")
            val email: Any,
            @SerializedName("full_name")
            val fullName: String,
            @SerializedName("id")
            val id: Int,
            @SerializedName("phone")
            val phone: String,
            @SerializedName("profile_pic")
            val profilePic: String,
            @SerializedName("service_provider_id")
            val serviceProviderId: Int
        )
    }
}
