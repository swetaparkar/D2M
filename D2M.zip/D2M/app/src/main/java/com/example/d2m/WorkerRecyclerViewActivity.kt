package com.example.d2m

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.d2m.adapter.WorkerAdapter
import com.example.d2m.model.HomeResponse1
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class WorkerRecyclerViewActivity : AppCompatActivity() {
    private lateinit var workerRecyclerView: RecyclerView
    private lateinit var newArrayList: ArrayList<Worker>
    lateinit var imageId : Array<Int>
    lateinit var name : Array<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sp_dash_board)

        supportActionBar?.hide()
        workerRecyclerView.setHasFixedSize(true)
        var linearLayoutManager = LinearLayoutManager(this)

       // workerRecyclerView = findViewById(R.id.recyclerview2)
        workerRecyclerView.layoutManager = LinearLayoutManager(this,LinearLayoutManager.VERTICAL ,false)
        workerRecyclerView.setHasFixedSize(true)
        newArrayList = arrayListOf()

        getUserdata()
        val apiInterface = ApiInterface.create().worker(74,"17", "17", "null", 0, 0,"")
        apiInterface.enqueue(object : Callback<HomeResponse1> {
            override fun onResponse(
                call: Call<HomeResponse1>,
                response: Response<HomeResponse1>,
            ) {
                Log.d("Success:", response.body().toString())
                if (response.body()?.success == true)

                else {
                    Toast.makeText(applicationContext,
                        response.body()?.message,
                        Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(call: Call<HomeResponse1>, t: Throwable) {
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }
    private fun getUserdata() {
        val worker =null
        workerRecyclerView.adapter = worker?.let { WorkerAdapter(it) }
    }
}
