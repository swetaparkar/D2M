package com.example.d2m

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.example.d2m.model.LoginApiResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

const val BASE_URL = "/api/v1/service-provider/login"

class ServiceProviderLoginActivity : AppCompatActivity() {

    // private val sharedPref = "sharedPreference"
    var editTextEmail: EditText? = null
    var editTextPassword: EditText? = null

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_service_provider_login)
        supportActionBar?.hide()

        editTextEmail = findViewById(R.id.editText_sp_email)
        editTextPassword = findViewById(R.id.editText_sp_password)
        loginServiceProvider()
    }

    private fun loginServiceProvider() {
        val btnSpLogin = findViewById<Button>(R.id.button_sp_login)
        btnSpLogin.setOnClickListener {
            if (TextUtils.isEmpty(editTextEmail?.text.toString())) {
                Toast.makeText(this@ServiceProviderLoginActivity,
                    " Please Enter Email",
                    Toast.LENGTH_SHORT).show()

            } else if (TextUtils.isEmpty(editTextPassword?.text.toString())) {
                Toast.makeText(this@ServiceProviderLoginActivity,
                    " Please Enter Password",
                    Toast.LENGTH_SHORT).show()
            } else {
                val apiInterface = ApiInterface.create()
                    .serviceProviderLogin(editTextEmail?.text.toString(),
                        editTextPassword?.text.toString(),
                        "Mithil12313",
                        "ios", 0, 7586666767, "0")
                apiInterface.enqueue(object : Callback<LoginApiResponse> {
                    override fun onResponse(
                        call: Call<LoginApiResponse>,
                        response: Response<LoginApiResponse>,
                    ) {
                        Log.d("Success:", response.body().toString())
                        if (response.body()?.success == true) {

                            SharedPrefManager.getInstance(applicationContext)
                                .saveUser(response.body()!!.data)

                            val intent = Intent(applicationContext, SpDbActivity::class.java)

                            intent.flags =
                                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

                            intent.putExtra("token", response.body()!!.data.token.toString())
                            startActivity(intent)

                        } else {
                            Toast.makeText(applicationContext,
                                response.body()?.message,
                                Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<LoginApiResponse>, t: Throwable) {
                        Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (SharedPrefManager.getInstance(this).isLoggedIn) {
            val intent = Intent(applicationContext, SpDbActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
    }
}