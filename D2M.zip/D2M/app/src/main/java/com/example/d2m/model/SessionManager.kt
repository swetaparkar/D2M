package com.example.d2m.model

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings.Global.getString
import com.example.d2m.R
import com.example.d2m.SpDashBoardActivity
import com.example.d2m.SpDbActivity
import com.example.d2m.ui.fragments.HomeFragment

class SessionManager(context: HomeFragment) {
    /*private var prefs: SharedPreferences = context.getSharedPreferences(context.getString(R.string.app_name), Context.MODE_PRIVATE)
    companion object {
        const val USER_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiMTliNGQ3NGI2ODE2NWUwZmY0NjA1MTY2N2FkMDg0YTAwODY2ZWE1NmY0NjI5MGEzOWM5NDMzMjFiZjYyZWZkOGJkNmI5ZGM4MjE2ZjgzZmUiLCJpYXQiOjE2NDU1OTUwMTksIm5iZiI6MTY0NTU5NTAxOSwiZXhwIjoxNjc3MTMxMDE5LCJzdWIiOiIxNyIsInNjb3BlcyI6W119.nkAyu0UFF_vkqcfRRXIRp_Gj1xO6BATHcy-SxI9z0Tqfl-ujJkGuhOc_XXUj1IkIcIu5ZtS0f6v3wayUKGNuRG9FiJzn6MPVVlgwTsYKz6cA0n5YKTss3-15KK_1Upu73AKmgvqYwHmoSQaE8MOdUD-UDlwRMLeFtQUzWsFUq_b0OUnI-FsJdQGkkf7jkQeY9WdJpHRSPNA_FE5yGys-iAwZEA7t3dmyb4VvXV-Qjri5HbraM9Xx4EchkzqPZcx_yEYNNOGxpOtu1Uq7zzFLB0sCQZEYfBQZE2kxW0D9r4kxmlWX6UA2lEyLEiBo8LquvvrFpSN02HV4ha4-ye2HJa9DVqLZ89usgv2unzYYGq3ZI0dLH8ZTsUHHITWqfrUsZZHv7lZeRgc2V7bp_G2F7gXX0IATMLTOtNS0GbFAwRgaiuyzqWmhOB7ct6dAUlGJVD2WpdrRusgsW_EONLRRg0MGpN8iwCYaeJEOwwnyfrMUO4xYuAfYwik5I4HHNGGPkdpj-7EyOCV7OvJhS7mIRW-oE_cGtHKoOyzySTnOZUEfBaz1F654YETJHzZxVmjTvf-tkSDUz4R_PlvpOc3QpB9giTOWEq5HSSJTKLgkJmQUehkKCpEdiksbckgYd6asA9IVEtJZI1gzzjgsyQHjjawReGa1a3F8FozahpazKH4"
    }
    fun saveAuthToken(token: String) {
        val editor = prefs.edit()
        editor.putString(USER_TOKEN, token)
        editor.apply()
    }

    fun fetchAuthToken(): String? {
        return prefs.getString(USER_TOKEN, null)
    }*/
}