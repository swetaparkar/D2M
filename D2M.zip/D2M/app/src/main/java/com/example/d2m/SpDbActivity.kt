package com.example.d2m

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.d2m.adapter.ProfileAdapter
import com.example.d2m.model.HomeResponse1
import com.example.d2m.model.SessionManager
import com.example.d2m.ui.fragments.HomeFragment
import com.example.d2m.ui.fragments.OrderFragment
import kotlinx.android.synthetic.main.activity_sp_db.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.collections.ArrayList

class SpDbActivity : AppCompatActivity() {
   val BASE_URL_HOME = "api/v1/service-provider/service-provider-home"
    //calendar
   /* private val lastDayInCalendar = Calendar.getInstance(Locale.ENGLISH)
    private val sdf = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
    private val cal = Calendar.getInstance(Locale.ENGLISH)

    private val currentDate = Calendar.getInstance(Locale.ENGLISH)
    private val currentDay = currentDate[Calendar.DAY_OF_MONTH]
    private val currentMonth = currentDate[Calendar.MONTH]
    private val currentYear = currentDate[Calendar.YEAR]

    private var selectedDay: Int = currentDay
    private var selectedMonth: Int = currentMonth
    private var selectedYear: Int = currentYear
    private val dates = ArrayList<Date>()*/

    //token
    private lateinit var sessionManager: SessionManager
    private lateinit var apiClient: ApiClient
    lateinit var myAdapter: ProfileAdapter
    var dataList = ArrayList<HomeResponse1>()

    private lateinit var newRecyclerView: RecyclerView
    private var newArrayList: ArrayList<HomeResponse1.Data.Technician>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sp_db)
        supportActionBar?.hide()

        //calender
       /* val snapHelper = LinearSnapHelper()
        snapHelper.attachToRecyclerView(calendar_recycler_view)

        lastDayInCalendar.add(Calendar.MONTH, 6)*/

        var token = intent.getStringExtra("token")
        var userID = intent.getStringExtra("userID")
        //token
        apiClient = ApiClient()
       // sessionManager = SessionManager(this)
        getUserdata(userID, token)
       // setUpCalendar()

        val homeFragment = HomeFragment()
        val orderFragment = OrderFragment()
        val technicianFragment = TechnicianFragment()
        val profileFragment = TechnicianProfileFragment()

        setCurrentFragment(homeFragment)

        bottomNavigationView.setOnNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.homeFragment -> setCurrentFragment(homeFragment)
                R.id.orderFragment -> setCurrentFragment(orderFragment)
                R.id.technicianFragment -> setCurrentFragment(technicianFragment)
                R.id.profileFragment -> setCurrentFragment(profileFragment)

            }
            true
        }
    }
    //calender
   /* private fun setUpCalendar(changeMonth: Calendar? = null) {
        //first
        txt_current_month!!.text = sdf.format(cal.time)
        val monthCalendar = cal.clone() as Calendar
        val maxDaysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

        selectedDay =
            when {
                changeMonth != null -> changeMonth.getActualMinimum(Calendar.DAY_OF_MONTH)
                else -> currentDay
            }
        selectedMonth =
            when {
                changeMonth != null -> changeMonth[Calendar.MONTH]
                else -> currentMonth
            }
        selectedYear =
            when {
                changeMonth != null -> changeMonth[Calendar.YEAR]
                else -> currentYear
            }
        //second
        var currentPosition = 0
        dates.clear()
        monthCalendar.set(Calendar.DAY_OF_MONTH, 1)

        while (dates.size < maxDaysInMonth) {
            if (monthCalendar[Calendar.DAY_OF_MONTH] == selectedDay)
                currentPosition = dates.size
            dates.add(monthCalendar.time)
            monthCalendar.add(Calendar.DAY_OF_MONTH, 1)
        }
        //third
        val layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        calendar_recycler_view!!.layoutManager = layoutManager
        val calendarAdapter = CalendarAdapter(this, dates, currentDate, changeMonth)
        calendar_recycler_view!!.adapter = calendarAdapter

        when{
            currentPosition > 2 -> calendar_recycler_view!!.scrollToPosition(currentPosition -3)
            maxDaysInMonth - currentPosition < 2 -> calendar_recycler_view!!.scrollToPosition(currentPosition)
            else -> calendar_recycler_view!!.scrollToPosition(currentPosition)
        }
        calendarAdapter.setOnItemClickListener(object : CalendarAdapter.OnItemClickListener {
            override fun onItemClick(position: Int) {
                val clickCalendar = Calendar.getInstance()
                clickCalendar.time = dates[position]
                selectedDay = clickCalendar[Calendar.DAY_OF_MONTH]
            }

            override fun onItemClick(parent: AdapterView<*>?, view: View?, position: Int, id: Long, ) {

            }
        })
    }*/

    //bottom nav
    private fun setCurrentFragment(fragment: Fragment)=
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.flFragment,fragment)
            commit()
        }

    private fun getUserdata(userID: String?, token: String?) {
        val apiInterface =
            ApiInterface.create().serviceProviderHome(userID ?: "17", "2022-01-11")
        apiInterface.enqueue(object : Callback<HomeResponse1> {

            override fun onResponse(
                call: Call<HomeResponse1>,
                response: Response<HomeResponse1>,
            ) {
                Log.d("Success:", response.body().toString())
                if (response.body()?.success == true) {
                    response.body()?.let {
                        dataList.addAll(arrayListOf(it))
                    }
                    response.body()?.data?.technician?.let { newArrayList?.addAll(it) }
                    response.body()?.data?.technician?.apply {
                        myAdapter = ProfileAdapter(this)
                        newRecyclerView.adapter = myAdapter
                        newRecyclerView.adapter!!.notifyDataSetChanged()
                    }
                } else {
                    Toast.makeText(applicationContext,
                        response.body()?.message,
                        Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(call: Call<HomeResponse1>, t: Throwable) {
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }
}
