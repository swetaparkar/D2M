package com.example.d2m

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils.replace
import android.view.*
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.SearchView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import androidx.fragment.app.replace
import com.example.d2m.ui.fragments.HomeFragment
import kotlinx.android.extensions.ContainerOptions
import kotlinx.android.synthetic.main.fragment_technician.*

class TechnicianFragment : Fragment() {
    lateinit var searchView: SearchView
    private lateinit var listView: ListView
    lateinit var list: ArrayList<String>
    lateinit var adapter: ArrayAdapter<*>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
       /* btn_addTechnician.setOnClickListener {
            val intent = Intent(context, AddTechnicianFormActivity::class.java)
            startActivity(intent)
        }*/
        return inflater.inflate(R.layout.fragment_technician, container, false)
    }
    }
        /*listView = view?.findViewById<ListView>(R.id.recyclerListView_technician)
            ?: return inflater.inflate(R.layout.fragment_technician, container, false)
        list = ArrayList()
        list.add("Technician1")
        list.add("Technician2")
        list.add("Technician3")
        list.add("Technician4")
        list.add("Technician5")
        list.add("Technician6")
        list.add("Technician7")
        list.add("Technician18")
        adapter =
            context?.let { ArrayAdapter<String>(it, android.R.layout.simple_list_item_1, list) }!!
        listView.adapter = adapter
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (list.contains(query)) {
                    adapter.filter.filter(query)
                } else {
                    Toast.makeText(context, "Technician not found", Toast.LENGTH_SHORT).show()
                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                adapter.filter.filter(newText)
                return false
            }

        })
        return null

    }
}
*/

