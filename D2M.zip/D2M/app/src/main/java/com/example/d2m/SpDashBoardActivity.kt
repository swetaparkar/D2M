package com.example.d2m

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.d2m.adapter.ProfileAdapter
import com.example.d2m.model.HomeResponse1
import com.example.d2m.model.SessionManager
import com.example.d2m.ui.fragments.HomeFragment
import com.example.d2m.ui.fragments.OrderFragment
import kotlinx.android.synthetic.main.activity_sp_db.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

const val BASE_URL_HOME = "api/v1/service-provider/service-provider-home"

class SpDashBoardActivity : AppCompatActivity() {
    //token
    private lateinit var sessionManager: SessionManager
    private lateinit var apiClient: ApiClient
    lateinit var myAdapter: ProfileAdapter
    var dataList = ArrayList<HomeResponse1>()

    private lateinit var newRecyclerView: RecyclerView
    private var newArrayList: ArrayList<HomeResponse1.Data.Technician>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sp_dash_board)
        supportActionBar?.hide()

        var token = intent.getStringExtra("token")
        var userID = intent.getStringExtra("userID")
        //token
        apiClient = ApiClient()
       // sessionManager = SessionManager(this)
        getUserdata(userID, token)
        //  bottomNavigation()
        val homeFragment = HomeFragment()
        val orderFragment = OrderFragment()
        val technicianFragment = TechnicianFragment()
        val profileFragment = TechnicianProfileFragment()

        setCurrentFragment(homeFragment)

        bottomNavigationView.setOnNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.homeFragment -> setCurrentFragment(homeFragment)
                R.id.orderFragment -> setCurrentFragment(orderFragment)
                R.id.technicianFragment -> setCurrentFragment(technicianFragment)
                R.id.profileFragment -> setCurrentFragment(profileFragment)

            }
            true
        }
    }private fun setCurrentFragment(fragment: Fragment)=
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.flFragment,fragment)
            commit()
        }

    private fun getUserdata(userID: String?, token: String?) {
        val apiInterface =
            ApiInterface.create().serviceProviderHome(userID ?: "17", "2022-01-11")
        apiInterface.enqueue(object : Callback<HomeResponse1> {

            override fun onResponse(
                call: Call<HomeResponse1>,
                response: Response<HomeResponse1>,
            ) {
                Log.d("Success:", response.body().toString())
                if (response.body()?.success == true) {
                    response.body()?.let {
                        dataList.addAll(arrayListOf(it))
                    }
                    response.body()?.data?.technician?.let { newArrayList?.addAll(it) }
                    response.body()?.data?.technician?.apply {
                        myAdapter = ProfileAdapter(this)
                        newRecyclerView.adapter = myAdapter
                        newRecyclerView.adapter!!.notifyDataSetChanged()
                    }
                } else {
                    Toast.makeText(applicationContext,
                        response.body()?.message,
                        Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<HomeResponse1>, t: Throwable) {
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }
}
