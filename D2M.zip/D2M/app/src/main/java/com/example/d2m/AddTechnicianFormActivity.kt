package com.example.d2m

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AddTechnicianFormActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_technician_form)
    }
}