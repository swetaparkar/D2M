package com.example.d2m.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.example.d2m.R
import com.example.d2m.adapter.PageAdapter
import com.google.android.material.tabs.TabLayout

class OrderFragment : Fragment(R.layout.fragment_order) {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?,
    ): View? {
        return inflater.inflate(R.layout.fragment_order, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

       val viewPager: ViewPager = view.findViewById(R.id.viewPager)

       // viewPager.adapter = PageAdapter(supportFragmentManager)


         val tabLayout: TabLayout = view.findViewById(R.id.tabLayout)
        tabLayout.setupWithViewPager(viewPager)


    }
}